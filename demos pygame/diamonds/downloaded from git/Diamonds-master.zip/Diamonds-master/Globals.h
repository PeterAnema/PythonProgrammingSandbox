#ifndef _GLOBALS_H
#define _GLOBALS_H

#include "HiScore.h"
#include "Field.h"

extern bool gameOn;

extern HiScore* scores;

extern Field* field;

#endif
