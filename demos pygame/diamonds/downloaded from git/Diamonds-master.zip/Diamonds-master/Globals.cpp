#include "Globals.h"
#include "HiScore.h"
#include "Field.h"

bool gameOn = false;

HiScore* scores = NULL;

Field* field = NULL;
